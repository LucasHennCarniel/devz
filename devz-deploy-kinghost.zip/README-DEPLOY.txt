# 📦 PACOTE DE DEPLOY - DEVZ KINGHOST

## 📂 Conteúdo do pacote:
- build/              (Arquivos compilados do frontend)
- server.js           (Servidor Express)
- package.json        (Dependências do projeto)
- ecosystem.config.json (Configuração PM2)
- .env               (Variáveis de ambiente)

## 🚀 Instruções de deploy:

### 1. Upload dos arquivos:
- Faça upload de TODOS os arquivos deste pacote para seu servidor KingHost
- Mantenha a estrutura de pastas

### 2. No servidor KingHost:
```bash
# Instalar dependências
npm install --production

# Iniciar aplicação
pm2 start ecosystem.config.json
```

### 3. Configurações importantes:
- Verifique se as variáveis no arquivo .env estão corretas
- A aplicação rodará na porta 3000 por padrão
- Configure seu domínio para apontar para a aplicação

### 4. Monitoramento:
```bash
# Ver status da aplicação
pm2 status

# Ver logs
pm2 logs devz-frontend
```

## 📞 Suporte:
- KingHost: (51) 3550-3200
- Documentação: Consulte DEPLOY-KINGHOST.md no projeto original

---
Gerado em: 07/10/2025 16:13:24,44
