
  # Gráfico de Crescimento

  This is a code bundle for Gráfico de Crescimento. The original project is available at https://www.figma.com/design/HBKccPriaNVxlOphWmP9Ae/Gr%C3%A1fico-de-Crescimento.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  