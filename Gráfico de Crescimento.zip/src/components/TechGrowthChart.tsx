import { useState } from 'react';
import { Code, Database, Brain, TrendingUp, BarChart3, Calculator, ArrowUpRight } from 'lucide-react';

interface Milestone {
  year: number;
  title: string;
  description: string;
  technologies: string[];
  icon: React.ReactNode;
  value: number;
}

const milestones: Milestone[] = [
  {
    year: 2019,
    title: "Fundação da Devz",
    description: "Início das atividades focadas em desenvolvimento de software personalizado.",
    technologies: ["JavaScript", "HTML/CSS", "Node.js", "MySQL"],
    icon: <Code className="w-4 h-4" />,
    value: 25
  },
  {
    year: 2020,
    title: "Primeira Linha ERP",
    description: "Lançamento do primeiro sistema ERP modular para pequenas empresas.",
    technologies: ["React", "Express.js", "PostgreSQL", "Docker"],
    icon: <Database className="w-4 h-4" />,
    value: 45
  },
  {
    year: 2021,
    title: "Expansão para IA",
    description: "Incorporação de soluções de Inteligência Artificial nos produtos.",
    technologies: ["Python", "TensorFlow", "FastAPI", "Redis"],
    icon: <Brain className="w-4 h-4" />,
    value: 65
  },
  {
    year: 2022,
    title: "Linha Avante®",
    description: "Desenvolvimento da linha completa Avante® para diversos segmentos.",
    technologies: ["TypeScript", "Next.js", "MongoDB", "AWS"],
    icon: <TrendingUp className="w-4 h-4" />,
    value: 80
  },
  {
    year: 2023,
    title: "Business Intelligence",
    description: "Especialização em dashboards e relatórios avançados com Power BI.",
    technologies: ["Power BI", "Azure", "GraphQL", "Elasticsearch"],
    icon: <BarChart3 className="w-4 h-4" />,
    value: 92
  },
  {
    year: 2024,
    title: "Automação Contábil",
    description: "Lançamento de soluções completas de automação contábil com Python + IA.",
    technologies: ["Python", "Machine Learning", "Kubernetes", "Microservices"],
    icon: <Calculator className="w-4 h-4" />,
    value: 100
  }
];

export function TechGrowthChart() {
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  return (
    <div className="w-full max-w-7xl mx-auto p-8">
      {/* Header */}
      <div className="text-center mb-16">
        <div className="inline-flex items-center gap-3 mb-6">
          <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
          <h1 className="text-foreground">Evolução Tecnológica</h1>
          <div className="w-2 h-2 bg-primary rounded-full animate-pulse delay-500"></div>
        </div>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Nossa jornada de crescimento e inovação ao longo dos anos
        </p>
      </div>

      {/* Chart Container */}
      <div className="relative">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-[0.02]">
          <div className="w-full h-full" style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgb(0 0 0) 1px, transparent 0)`,
            backgroundSize: '24px 24px'
          }}></div>
        </div>

        {/* Growth Trend Line */}
        <svg 
          className="absolute inset-0 w-full h-full pointer-events-none z-10" 
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="trendGradient" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="rgb(59 130 246)" stopOpacity="0.3" />
              <stop offset="50%" stopColor="rgb(29 78 216)" stopOpacity="0.5" />
              <stop offset="100%" stopColor="rgb(29 78 216)" stopOpacity="0.7" />
            </linearGradient>
          </defs>
          <path
            d={`M 8% 85% Q 30% 60%, 50% 40% T 92% 15%`}
            stroke="url(#trendGradient)"
            strokeWidth="3"
            fill="none"
            strokeDasharray="8,4"
            className="animate-pulse"
          />
        </svg>

        {/* Chart Bars */}
        <div className="relative grid grid-cols-6 gap-6 h-80">
          {milestones.map((milestone, index) => (
            <div 
              key={milestone.year}
              className="flex flex-col justify-end group cursor-pointer"
              onMouseEnter={() => setActiveIndex(index)}
              onMouseLeave={() => setActiveIndex(null)}
            >
              {/* Value Display */}
              <div className={`text-center mb-3 transition-all duration-300 ${
                activeIndex === index ? 'opacity-100 scale-110' : 'opacity-70'
              }`}>
                <div className={`text-2xl mb-1 transition-colors duration-300 ${
                  milestone.value >= 80 ? 'text-blue-700' :
                  milestone.value >= 60 ? 'text-blue-600' :
                  milestone.value >= 40 ? 'text-blue-500' :
                  milestone.value >= 20 ? 'text-blue-400' : 'text-blue-300'
                }`}>{milestone.value}</div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider">
                  Índice
                </div>
              </div>

              {/* Bar */}
              <div
                className={`w-full rounded-lg transition-all duration-500 relative overflow-hidden ${
                  activeIndex === index ? 'shadow-lg shadow-blue-500/20' : ''
                }`}
                style={{ 
                  height: `${(milestone.value / 100) * 200}px`,
                  minHeight: '32px',
                  background: `linear-gradient(to top, 
                    ${milestone.value >= 80 ? 'rgb(29 78 216)' : 
                      milestone.value >= 60 ? 'rgb(59 130 246)' : 
                      milestone.value >= 40 ? 'rgb(96 165 250)' : 
                      milestone.value >= 20 ? 'rgb(147 197 253)' : 'rgb(191 219 254)'}, 
                    ${milestone.value >= 80 ? 'rgb(59 130 246)' : 
                      milestone.value >= 60 ? 'rgb(96 165 250)' : 
                      milestone.value >= 40 ? 'rgb(147 197 253)' : 
                      milestone.value >= 20 ? 'rgb(191 219 254)' : 'rgb(219 234 254)'})`
                }}
              >
                {/* Animated Pulse */}
                <div 
                  className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-blue-600/30 to-blue-400/30 rounded-lg transition-all duration-700 ease-out"
                  style={{ 
                    height: activeIndex === index ? '100%' : '0%',
                    opacity: activeIndex === index ? 1 : 0
                  }}
                />

                {/* Icon */}
                <div className={`absolute top-3 left-1/2 transform -translate-x-1/2 p-2 rounded-md transition-all duration-300 ${
                  activeIndex === index 
                    ? 'bg-white text-blue-600 shadow-md' 
                    : milestone.value >= 60 
                      ? 'bg-white text-blue-600 shadow-sm' 
                      : 'bg-white/90 text-blue-500'
                }`}>
                  {milestone.icon}
                </div>

                {/* Glow Effect */}
                {activeIndex === index && (
                  <div className="absolute inset-0 bg-gradient-to-t from-blue-500/10 to-transparent rounded-lg animate-pulse" />
                )}

                {/* Shimmer Effect */}
                <div className={`absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 transform transition-transform duration-1000 ${
                  activeIndex === index ? 'translate-x-[-100%] animate-[shimmer_2s_ease-in-out_infinite]' : 'translate-x-[-200%]'
                }`} style={{
                  animation: activeIndex === index ? 'shimmer 2s ease-in-out infinite' : 'none'
                }}></div>
              </div>

              {/* Year Label */}
              <div className={`text-center mt-4 transition-all duration-300 ${
                activeIndex === index ? 'text-foreground' : 'text-muted-foreground'
              }`}>
                <div className="px-3 py-1 rounded-full bg-background border border-border text-sm">
                  {milestone.year}
                </div>
              </div>
            </div>
          ))}
        </div>


      </div>

      {/* Active Milestone Details */}
      {activeIndex !== null && (
        <div className="mt-12 bg-card border border-border rounded-lg p-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-600 text-white rounded-md shadow-md">
                  {milestones[activeIndex].icon}
                </div>
                <div>
                  <h3 className="text-foreground">{milestones[activeIndex].title}</h3>
                  <div className="text-sm text-blue-600">{milestones[activeIndex].year}</div>
                </div>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                {milestones[activeIndex].description}
              </p>
            </div>
            <div>
              <h4 className="text-sm text-muted-foreground uppercase tracking-wider mb-4">
                Stack Tecnológico
              </h4>
              <div className="grid grid-cols-2 gap-2">
                {milestones[activeIndex].technologies.map((tech, index) => (
                  <div
                    key={index}
                    className="text-sm bg-muted text-muted-foreground px-3 py-2 rounded-md border border-border text-center"
                  >
                    {tech}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}


    </div>
  );
}