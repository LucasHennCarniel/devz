import { TechGrowthChart } from './components/TechGrowthChart';

export default function App() {
  return (
    <div className="min-h-screen bg-background">
      <TechGrowthChart />
    </div>
  );
}